import React from 'react';
import { ArtworkProps } from './artworkComponents';

const cursorClass = (interactive: boolean) =>
  interactive ? 'cursor-pointer hover:opacity-85 hover:stroke-amber-400 hover:stroke-[3px] transition-all' : '';

const getF = (parts: Record<string, string>, key: string, fallback: string) => parts[key] || fallback;

// 51. 🐜 ANT (3 Letters)
export const AntColorableSVG: React.FC<ArtworkProps> = ({ parts, onPartClick, interactive = true }) => {
  const cc = cursorClass(interactive);
  return (
    <g transform="translate(10, 10)">
      {/* Legs */}
      <line x1="85" y1="130" x2="60" y2="165" stroke="#1E293B" strokeWidth="4" strokeLinecap="round" />
      <line x1="120" y1="135" x2="120" y2="175" stroke="#1E293B" strokeWidth="4" strokeLinecap="round" />
      <line x1="155" y1="130" x2="180" y2="165" stroke="#1E293B" strokeWidth="4" strokeLinecap="round" />
      {/* Abdomen */}
      <ellipse cx="170" cy="120" rx="35" ry="28" fill={getF(parts, 'abdomen', '#DC2626')} stroke="#1E293B" strokeWidth="4.5" className={cc} onClick={() => interactive && onPartClick?.('abdomen')} />
      {/* Thorax */}
      <ellipse cx="120" cy="120" rx="20" ry="18" fill={getF(parts, 'thorax', '#991B1B')} stroke="#1E293B" strokeWidth="4.5" className={cc} onClick={() => interactive && onPartClick?.('thorax')} />
      {/* Head */}
      <circle cx="70" cy="115" r="26" fill={getF(parts, 'head', '#DC2626')} stroke="#1E293B" strokeWidth="4.5" className={cc} onClick={() => interactive && onPartClick?.('head')} />
      {/* Antennae */}
      <path d="M 65 90 Q 55 60 40 65" stroke="#1E293B" strokeWidth="3.5" strokeLinecap="round" fill="none" />
      <path d="M 75 90 Q 85 60 100 65" stroke="#1E293B" strokeWidth="3.5" strokeLinecap="round" fill="none" />
      {/* Big Cute Eye */}
      <circle cx="62" cy="108" r="6" fill="#1E293B" />
      <circle cx="60" cy="106" r="2" fill="white" />
      {/* Smile */}
      <path d="M 52 122 Q 62 130 68 122" stroke="#1E293B" strokeWidth="3" strokeLinecap="round" fill="none" />
    </g>
  );
};

// 52. 🐝 BEE (3 Letters)
export const BeeColorableSVG: React.FC<ArtworkProps> = ({ parts, onPartClick, interactive = true }) => {
  const cc = cursorClass(interactive);
  return (
    <g transform="translate(10, 10)">
      {/* Wings */}
      <ellipse cx="95" cy="70" rx="25" ry="35" transform="rotate(-25 95 70)" fill={getF(parts, 'wings', '#BAE6FD')} stroke="#1E293B" strokeWidth="4" className={cc} onClick={() => interactive && onPartClick?.('wings')} opacity="0.9" />
      <ellipse cx="145" cy="70" rx="25" ry="35" transform="rotate(25 145 70)" fill={getF(parts, 'wings', '#BAE6FD')} stroke="#1E293B" strokeWidth="4" className={cc} onClick={() => interactive && onPartClick?.('wings')} opacity="0.9" />
      {/* Body */}
      <ellipse cx="120" cy="135" rx="55" ry="42" fill={getF(parts, 'body', '#FBBF24')} stroke="#1E293B" strokeWidth="4.5" className={cc} onClick={() => interactive && onPartClick?.('body')} />
      {/* Stripes */}
      <path d="M 105 95 Q 108 135 105 175" stroke="#1E293B" strokeWidth="10" strokeLinecap="round" />
      <path d="M 135 95 Q 138 135 135 175" stroke="#1E293B" strokeWidth="10" strokeLinecap="round" />
      {/* Stinger */}
      <polygon points="175,130 195,135 175,140" fill="#1E293B" />
      {/* Cheeks */}
      <ellipse cx="75" cy="145" rx="7" ry="5" fill={getF(parts, 'cheeks', '#FDA4AF')} />
      {/* Eye */}
      <circle cx="82" cy="125" r="7" fill="#1E293B" />
      <circle cx="80" cy="122" r="2.5" fill="white" />
      {/* Antennae */}
      <path d="M 80 95 Q 65 75 60 80" stroke="#1E293B" strokeWidth="3.5" strokeLinecap="round" fill="none" />
      <circle cx="58" cy="80" r="3.5" fill="#1E293B" />
    </g>
  );
};

// 53. 🐮 COW (3 Letters)
export const CowColorableSVG: React.FC<ArtworkProps> = ({ parts, onPartClick, interactive = true }) => {
  const cc = cursorClass(interactive);
  return (
    <g transform="translate(10, 10)">
      {/* Horns */}
      <path d="M 75 75 Q 60 45 70 40 Q 85 55 85 75" fill={getF(parts, 'horns', '#F59E0B')} stroke="#1E293B" strokeWidth="3.5" />
      <path d="M 165 75 Q 180 45 170 40 Q 155 55 155 75" fill={getF(parts, 'horns', '#F59E0B')} stroke="#1E293B" strokeWidth="3.5" />
      {/* Ears */}
      <ellipse cx="55" cy="90" rx="20" ry="12" transform="rotate(-20 55 90)" fill={getF(parts, 'head', '#FFFFFF')} stroke="#1E293B" strokeWidth="4" />
      <ellipse cx="185" cy="90" rx="20" ry="12" transform="rotate(20 185 90)" fill={getF(parts, 'head', '#FFFFFF')} stroke="#1E293B" strokeWidth="4" />
      {/* Head */}
      <ellipse cx="120" cy="115" rx="55" ry="48" fill={getF(parts, 'head', '#FFFFFF')} stroke="#1E293B" strokeWidth="4.5" className={cc} onClick={() => interactive && onPartClick?.('head')} />
      {/* Black Spots */}
      <path d="M 80 80 Q 95 75 105 95 Q 85 110 80 80 Z" fill={getF(parts, 'spots', '#1E293B')} className={cc} onClick={() => interactive && onPartClick?.('spots')} />
      {/* Eyes */}
      <circle cx="92" cy="105" r="7" fill="#1E293B" />
      <circle cx="90" cy="102" r="2.5" fill="white" />
      <circle cx="148" cy="105" r="7" fill="#1E293B" />
      <circle cx="146" cy="102" r="2.5" fill="white" />
      {/* Snout */}
      <ellipse cx="120" cy="148" rx="42" ry="26" fill={getF(parts, 'snout', '#FDA4AF')} stroke="#1E293B" strokeWidth="4" className={cc} onClick={() => interactive && onPartClick?.('snout')} />
      <circle cx="106" cy="145" r="5" fill="#BE185D" />
      <circle cx="134" cy="145" r="5" fill="#BE185D" />
      <path d="M 112 158 Q 120 164 128 158" stroke="#BE185D" strokeWidth="3" strokeLinecap="round" fill="none" />
    </g>
  );
};

// 54. 🧢 CAP / HAT (3 Letters)
export const CapColorableSVG: React.FC<ArtworkProps> = ({ parts, onPartClick, interactive = true }) => {
  const cc = cursorClass(interactive);
  return (
    <g transform="translate(10, 15)">
      {/* Dome of Cap */}
      <path d="M 60 145 C 55 70, 185 70, 180 145 Z" fill={getF(parts, 'dome', '#3B82F6')} stroke="#1E293B" strokeWidth="5" className={cc} onClick={() => interactive && onPartClick?.('dome')} />
      {/* Visor / Brim */}
      <path d="M 50 145 Q 120 135 190 145 Q 220 165 175 175 Q 110 170 50 145 Z" fill={getF(parts, 'visor', '#1D4ED8')} stroke="#1E293B" strokeWidth="4.5" className={cc} onClick={() => interactive && onPartClick?.('visor')} />
      {/* Top Button */}
      <circle cx="120" cy="74" r="8" fill={getF(parts, 'button', '#FBBF24')} stroke="#1E293B" strokeWidth="3" />
      {/* Front Logo / Star */}
      <polygon points="120,95 125,110 140,110 128,120 132,135 120,125 108,135 112,120 100,110 115,110" fill={getF(parts, 'logo', '#FBBF24')} stroke="#1E293B" strokeWidth="2" />
    </g>
  );
};

// 55. 🥚 EGG (3 Letters)
export const EggColorableSVG: React.FC<ArtworkProps> = ({ parts, onPartClick, interactive = true }) => {
  const cc = cursorClass(interactive);
  return (
    <g transform="translate(10, 10)">
      {/* Egg Shell */}
      <path d="M 120 40 C 65 40, 50 125, 50 165 C 50 205, 80 220, 120 220 C 160 220, 190 205, 190 165 C 190 125, 175 40, 120 40 Z" fill={getF(parts, 'shell', '#FEF3C7')} stroke="#1E293B" strokeWidth="5" className={cc} onClick={() => interactive && onPartClick?.('shell')} />
      {/* Cute Face */}
      <circle cx="95" cy="140" r="7" fill="#1E293B" />
      <circle cx="93" cy="137" r="2.5" fill="white" />
      <circle cx="145" cy="140" r="7" fill="#1E293B" />
      <circle cx="143" cy="137" r="2.5" fill="white" />
      <ellipse cx="80" cy="155" rx="8" ry="5" fill={getF(parts, 'cheeks', '#FDA4AF')} />
      <ellipse cx="160" cy="155" rx="8" ry="5" fill={getF(parts, 'cheeks', '#FDA4AF')} />
      <path d="M 112 152 Q 120 162 128 152" stroke="#1E293B" strokeWidth="3.5" strokeLinecap="round" fill="none" />
      {/* Cute Star Bow */}
      <circle cx="120" cy="65" r="10" fill={getF(parts, 'ribbon', '#FB7185')} stroke="#1E293B" strokeWidth="3" />
    </g>
  );
};

// 56. 🦁 CUB / LION CUB (3 Letters)
export const CubColorableSVG: React.FC<ArtworkProps> = ({ parts, onPartClick, interactive = true }) => {
  const cc = cursorClass(interactive);
  return (
    <g transform="translate(10, 10)">
      <circle cx="70" cy="80" r="22" fill={getF(parts, 'head', '#F59E0B')} stroke="#1E293B" strokeWidth="4" />
      <circle cx="70" cy="80" r="12" fill={getF(parts, 'earsInner', '#FDA4AF')} />
      <circle cx="170" cy="80" r="22" fill={getF(parts, 'head', '#F59E0B')} stroke="#1E293B" strokeWidth="4" />
      <circle cx="170" cy="80" r="12" fill={getF(parts, 'earsInner', '#FDA4AF')} />
      <circle cx="120" cy="125" r="58" fill={getF(parts, 'head', '#FBBF24')} stroke="#1E293B" strokeWidth="4.5" className={cc} onClick={() => interactive && onPartClick?.('head')} />
      <circle cx="94" cy="115" r="7.5" fill="#1E293B" />
      <circle cx="92" cy="112" r="2.5" fill="white" />
      <circle cx="146" cy="115" r="7.5" fill="#1E293B" />
      <circle cx="144" cy="112" r="2.5" fill="white" />
      <ellipse cx="120" cy="142" rx="22" ry="14" fill={getF(parts, 'snout', '#FFFFFF')} stroke="#1E293B" strokeWidth="3.5" className={cc} onClick={() => interactive && onPartClick?.('snout')} />
      <polygon points="113,134 127,134 120,142" fill="#78350F" />
      <path d="M 120 142 L 120 148 M 112 148 Q 120 155 128 148" stroke="#1E293B" strokeWidth="3" strokeLinecap="round" fill="none" />
      <ellipse cx="80" cy="138" rx="8" ry="5" fill={getF(parts, 'cheeks', '#FB7185')} />
      <ellipse cx="160" cy="138" rx="8" ry="5" fill={getF(parts, 'cheeks', '#FB7185')} />
    </g>
  );
};

// 57. 📦 BOX (3 Letters)
export const BoxColorableSVG: React.FC<ArtworkProps> = ({ parts, onPartClick, interactive = true }) => {
  const cc = cursorClass(interactive);
  return (
    <g transform="translate(10, 10)">
      {/* Box base */}
      <polygon points="40,90 120,50 200,90 120,130" fill={getF(parts, 'top', '#FBBF24')} stroke="#1E293B" strokeWidth="4.5" className={cc} onClick={() => interactive && onPartClick?.('top')} />
      <polygon points="40,90 120,130 120,210 40,170" fill={getF(parts, 'leftSide', '#D97706')} stroke="#1E293B" strokeWidth="4.5" className={cc} onClick={() => interactive && onPartClick?.('leftSide')} />
      <polygon points="200,90 120,130 120,210 200,170" fill={getF(parts, 'rightSide', '#B45309')} stroke="#1E293B" strokeWidth="4.5" className={cc} onClick={() => interactive && onPartClick?.('rightSide')} />
      {/* Ribbon */}
      <path d="M 120 50 L 120 130 L 120 210" stroke={getF(parts, 'ribbon', '#EF4444')} strokeWidth="12" strokeLinecap="round" />
      <circle cx="120" cy="70" r="14" fill={getF(parts, 'ribbon', '#EF4444')} stroke="#1E293B" strokeWidth="3" />
    </g>
  );
};

// 58. 🛏️ BED (3 Letters)
export const BedColorableSVG: React.FC<ArtworkProps> = ({ parts, onPartClick, interactive = true }) => {
  const cc = cursorClass(interactive);
  return (
    <g transform="translate(10, 15)">
      {/* Headboard */}
      <rect x="40" y="70" width="25" height="110" rx="8" fill={getF(parts, 'frame', '#78350F')} stroke="#1E293B" strokeWidth="4.5" className={cc} onClick={() => interactive && onPartClick?.('frame')} />
      {/* Footboard */}
      <rect x="185" y="110" width="20" height="70" rx="6" fill={getF(parts, 'frame', '#78350F')} stroke="#1E293B" strokeWidth="4.5" />
      {/* Mattress */}
      <rect x="65" y="125" width="120" height="35" rx="6" fill={getF(parts, 'sheet', '#38BDF8')} stroke="#1E293B" strokeWidth="4" className={cc} onClick={() => interactive && onPartClick?.('sheet')} />
      {/* Blanket */}
      <rect x="100" y="120" width="85" height="42" rx="6" fill={getF(parts, 'blanket', '#EC4899')} stroke="#1E293B" strokeWidth="4" className={cc} onClick={() => interactive && onPartClick?.('blanket')} />
      {/* Pillow */}
      <ellipse cx="80" cy="115" rx="16" ry="12" fill={getF(parts, 'pillow', '#FFFFFF')} stroke="#1E293B" strokeWidth="3.5" className={cc} onClick={() => interactive && onPartClick?.('pillow')} />
    </g>
  );
};

// 59. 🦊 FOX CUB / TOY / KEY (3 Letters) - KEY
export const KeyColorableSVG: React.FC<ArtworkProps> = ({ parts, onPartClick, interactive = true }) => {
  const cc = cursorClass(interactive);
  return (
    <g transform="translate(10, 15)">
      {/* Key Bow (Head) */}
      <circle cx="80" cy="120" r="38" fill={getF(parts, 'keyHead', '#FBBF24')} stroke="#1E293B" strokeWidth="5" className={cc} onClick={() => interactive && onPartClick?.('keyHead')} />
      <circle cx="80" cy="120" r="18" fill="#FFFFFF" stroke="#1E293B" strokeWidth="4" />
      {/* Key Shaft */}
      <rect x="115" y="112" width="75" height="16" rx="4" fill={getF(parts, 'keyShaft', '#F59E0B')} stroke="#1E293B" strokeWidth="4.5" className={cc} onClick={() => interactive && onPartClick?.('keyShaft')} />
      {/* Key Teeth */}
      <rect x="160" y="128" width="14" height="22" rx="3" fill={getF(parts, 'keyShaft', '#F59E0B')} stroke="#1E293B" strokeWidth="3.5" />
      <rect x="180" y="128" width="10" height="15" rx="3" fill={getF(parts, 'keyShaft', '#F59E0B')} stroke="#1E293B" strokeWidth="3.5" />
    </g>
  );
};

// 60. 🌰 NUT (3 Letters)
export const NutColorableSVG: React.FC<ArtworkProps> = ({ parts, onPartClick, interactive = true }) => {
  const cc = cursorClass(interactive);
  return (
    <g transform="translate(10, 10)">
      {/* Acorn Cap */}
      <path d="M 60 100 C 60 65, 180 65, 180 100 Z" fill={getF(parts, 'cap', '#78350F')} stroke="#1E293B" strokeWidth="5" className={cc} onClick={() => interactive && onPartClick?.('cap')} />
      {/* Stem */}
      <path d="M 120 70 Q 120 40 135 35" stroke="#78350F" strokeWidth="6" strokeLinecap="round" fill="none" />
      {/* Nut Body */}
      <path d="M 65 100 C 65 180, 120 215, 120 215 C 120 215, 175 180, 175 100 Z" fill={getF(parts, 'body', '#D97706')} stroke="#1E293B" strokeWidth="5" className={cc} onClick={() => interactive && onPartClick?.('body')} />
      {/* Cute Face */}
      <circle cx="95" cy="135" r="7" fill="#1E293B" />
      <circle cx="93" cy="132" r="2.5" fill="white" />
      <circle cx="145" cy="135" r="7" fill="#1E293B" />
      <circle cx="143" cy="132" r="2.5" fill="white" />
      <ellipse cx="80" cy="148" rx="8" ry="5" fill={getF(parts, 'cheeks', '#FDA4AF')} />
      <ellipse cx="160" cy="148" rx="8" ry="5" fill={getF(parts, 'cheeks', '#FDA4AF')} />
      <path d="M 112 148 Q 120 156 128 148" stroke="#1E293B" strokeWidth="3.5" strokeLinecap="round" fill="none" />
    </g>
  );
};
