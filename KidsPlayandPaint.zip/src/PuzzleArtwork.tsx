import React from 'react';
import { RenderArtwork } from './artworkComponents';
import { WordItem } from './wordsData';

interface PuzzleArtworkProps {
  word: WordItem;
  revealedIndices: number[];
  activeWordUserColors?: Record<string, string>;
  onPieceClick?: (index: number) => void;
  interactive?: boolean;
}

export interface PieceGeometry {
  index: number;
  x: number;
  y: number;
  w: number;
  h: number;
  centerX: number;
  centerY: number;
  pathD: string;
}

// Generate puzzle pieces for word length N (3 to 10) on a 260x260 viewBox
export function generatePuzzlePieces(count: number, width = 260, height = 260): PieceGeometry[] {
  const pieces: PieceGeometry[] = [];
  const W = width;
  const H = height;

  if (count === 3) {
    const colW = W / 3;
    const x1 = colW;
    const x2 = colW * 2;

    pieces.push({
      index: 0,
      x: 0,
      y: 0,
      w: colW,
      h: H,
      centerX: colW / 2,
      centerY: H / 2,
      pathD: `M 0 0 L ${x1} 0 L ${x1} 90 C ${x1 + 18} 90, ${x1 + 18} 170, ${x1} 170 L ${x1} ${H} L 0 ${H} Z`,
    });

    pieces.push({
      index: 1,
      x: x1,
      y: 0,
      w: colW,
      h: H,
      centerX: x1 + colW / 2,
      centerY: H / 2,
      pathD: `M ${x1} 0 L ${x2} 0 L ${x2} 100 C ${x2 - 18} 100, ${x2 - 18} 160, ${x2} 160 L ${x2} ${H} L ${x1} ${H} L ${x1} 170 C ${x1 + 18} 170, ${x1 + 18} 90, ${x1} 90 Z`,
    });

    pieces.push({
      index: 2,
      x: x2,
      y: 0,
      w: colW,
      h: H,
      centerX: x2 + colW / 2,
      centerY: H / 2,
      pathD: `M ${x2} 0 L ${W} 0 L ${W} ${H} L ${x2} ${H} L ${x2} 160 C ${x2 - 18} 160, ${x2 - 18} 100, ${x2} 100 Z`,
    });
  } else if (count === 4) {
    const halfW = W / 2;
    const halfH = H / 2;

    pieces.push({
      index: 0,
      x: 0,
      y: 0,
      w: halfW,
      h: halfH,
      centerX: halfW / 2,
      centerY: halfH / 2,
      pathD: `M 0 0 L ${halfW} 0 L ${halfW} 45 C ${halfW + 16} 45, ${halfW + 16} 85, ${halfW} 85 L ${halfW} ${halfH} L 85 ${halfH} C 85 ${halfH + 16}, 45 ${halfH + 16}, 45 ${halfH} L 0 ${halfH} Z`,
    });

    pieces.push({
      index: 1,
      x: halfW,
      y: 0,
      w: halfW,
      h: halfH,
      centerX: halfW + halfW / 2,
      centerY: halfH / 2,
      pathD: `M ${halfW} 0 L ${W} 0 L ${W} ${halfH} L ${halfW + 85} ${halfH} C ${halfW + 85} ${halfH - 16}, ${halfW + 45} ${halfH - 16}, ${halfW + 45} ${halfH} L ${halfW} ${halfH} L ${halfW} 85 C ${halfW + 16} 85, ${halfW + 16} 45, ${halfW} 45 Z`,
    });

    pieces.push({
      index: 2,
      x: 0,
      y: halfH,
      w: halfW,
      h: halfH,
      centerX: halfW / 2,
      centerY: halfH + halfH / 2,
      pathD: `M 0 ${halfH} L 45 ${halfH} C 45 ${halfH + 16}, 85 ${halfH + 16}, 85 ${halfH} L ${halfW} ${halfH} L ${halfW} ${halfH + 45} C ${halfW - 16} ${halfH + 45}, ${halfW - 16} ${halfH + 85}, ${halfW} ${halfH + 85} L ${halfW} ${H} L 0 ${H} Z`,
    });

    pieces.push({
      index: 3,
      x: halfW,
      y: halfH,
      w: halfW,
      h: halfH,
      centerX: halfW + halfW / 2,
      centerY: halfH + halfH / 2,
      pathD: `M ${halfW} ${halfH} L ${halfW + 45} ${halfH} C ${halfW + 45} ${halfH - 16}, ${halfW + 85} ${halfH - 16}, ${halfW + 85} ${halfH} L ${W} ${halfH} L ${W} ${H} L ${halfW} ${H} L ${halfW} ${halfH + 85} C ${halfW - 16} ${halfH + 85}, ${halfW - 16} ${halfH + 45}, ${halfW} ${halfH + 45} Z`,
    });
  } else if (count === 5) {
    const halfH = H / 2;
    const topW = W / 2;
    const btmW = W / 3;

    pieces.push({
      index: 0,
      x: 0,
      y: 0,
      w: topW,
      h: halfH,
      centerX: topW / 2,
      centerY: halfH / 2,
      pathD: `M 0 0 L ${topW} 0 L ${topW} 45 C ${topW + 15} 45, ${topW + 15} 85, ${topW} 85 L ${topW} ${halfH} L 0 ${halfH} Z`,
    });

    pieces.push({
      index: 1,
      x: topW,
      y: 0,
      w: topW,
      h: halfH,
      centerX: topW + topW / 2,
      centerY: halfH / 2,
      pathD: `M ${topW} 0 L ${W} 0 L ${W} ${halfH} L ${topW} ${halfH} L ${topW} 85 C ${topW + 15} 85, ${topW + 15} 45, ${topW} 45 Z`,
    });

    for (let c = 0; c < 3; c++) {
      const bx0 = c * btmW;
      const bx1 = (c + 1) * btmW;
      let path = '';
      if (c === 0) {
        path = `M 0 ${halfH} L ${bx1} ${halfH} L ${bx1} ${halfH + 45} C ${bx1 + 14} ${halfH + 45}, ${bx1 + 14} ${halfH + 85}, ${bx1} ${halfH + 85} L ${bx1} ${H} L 0 ${H} Z`;
      } else if (c === 1) {
        path = `M ${bx0} ${halfH} L ${bx1} ${halfH} L ${bx1} ${halfH + 50} C ${bx1 - 14} ${halfH + 50}, ${bx1 - 14} ${halfH + 80}, ${bx1} ${halfH + 80} L ${bx1} ${H} L ${bx0} ${H} L ${bx0} ${halfH + 85} C ${bx0 + 14} ${halfH + 85}, ${bx0 + 14} ${halfH + 45}, ${bx0} ${halfH + 45} Z`;
      } else {
        path = `M ${bx0} ${halfH} L ${W} ${halfH} L ${W} ${H} L ${bx0} ${H} L ${bx0} ${halfH + 80} C ${bx0 - 14} ${halfH + 80}, ${bx0 - 14} ${halfH + 50}, ${bx0} ${halfH + 50} Z`;
      }

      pieces.push({
        index: 2 + c,
        x: bx0,
        y: halfH,
        w: btmW,
        h: halfH,
        centerX: bx0 + btmW / 2,
        centerY: halfH + halfH / 2,
        pathD: path,
      });
    }
  } else if (count === 6) {
    const halfH = H / 2;
    const colW = W / 3;

    for (let r = 0; r < 2; r++) {
      const y0 = r * halfH;
      const y1 = (r + 1) * halfH;
      for (let c = 0; c < 3; c++) {
        const x0 = c * colW;
        const x1 = (c + 1) * colW;
        const idx = r * 3 + c;
        let path = '';
        if (r === 0) {
          if (c === 0) {
            path = `M 0 0 L ${x1} 0 L ${x1} 45 C ${x1 + 12} 45, ${x1 + 12} 85, ${x1} 85 L ${x1} ${halfH} L 55 ${halfH} C 55 ${halfH + 12}, 25 ${halfH + 12}, 25 ${halfH} L 0 ${halfH} Z`;
          } else if (c === 1) {
            path = `M ${x0} 0 L ${x1} 0 L ${x1} 45 C ${x1 + 12} 45, ${x1 + 12} 85, ${x1} 85 L ${x1} ${halfH} L ${x0 + 55} ${halfH} C ${x0 + 55} ${halfH - 12}, ${x0 + 25} ${halfH - 12}, ${x0 + 25} ${halfH} L ${x0} ${halfH} L ${x0} 85 C ${x0 + 12} 85, ${x0 + 12} 45, ${x0} 45 Z`;
          } else {
            path = `M ${x0} 0 L ${W} 0 L ${W} ${halfH} L ${x0 + 55} ${halfH} C ${x0 + 55} ${halfH + 12}, ${x0 + 25} ${halfH + 12}, ${x0 + 25} ${halfH} L ${x0} ${halfH} L ${x0} 85 C ${x0 + 12} 85, ${x0 + 12} 45, ${x0} 45 Z`;
          }
        } else {
          if (c === 0) {
            path = `M 0 ${halfH} L 25 ${halfH} C 25 ${halfH + 12}, 55 ${halfH + 12}, 55 ${halfH} L ${x1} ${halfH} L ${x1} ${halfH + 45} C ${x1 + 12} ${halfH + 45}, ${x1 + 12} ${halfH + 85}, ${x1} ${halfH + 85} L ${x1} ${H} L 0 ${H} Z`;
          } else if (c === 1) {
            path = `M ${x0} ${halfH} L ${x0 + 25} ${halfH} C ${x0 + 25} ${halfH - 12}, ${x0 + 55} ${halfH - 12}, ${x0 + 55} ${halfH} L ${x1} ${halfH} L ${x1} ${halfH + 45} C ${x1 + 12} ${halfH + 45}, ${x1 + 12} ${halfH + 85}, ${x1} ${halfH + 85} L ${x1} ${H} L ${x0} ${H} L ${x0} ${halfH + 85} C ${x0 + 12} ${halfH + 85}, ${x0 + 12} ${halfH + 45}, ${x0} ${halfH + 45} Z`;
          } else {
            path = `M ${x0} ${halfH} L ${x0 + 25} ${halfH} C ${x0 + 25} ${halfH + 12}, ${x0 + 55} ${halfH + 12}, ${x0 + 55} ${halfH} L ${W} ${halfH} L ${W} ${H} L ${x0} ${H} L ${x0} ${halfH + 85} C ${x0 + 12} ${halfH + 85}, ${x0 + 12} ${halfH + 45}, ${x0} ${halfH + 45} Z`;
          }
        }
        pieces.push({
          index: idx,
          x: x0,
          y: y0,
          w: colW,
          h: halfH,
          centerX: x0 + colW / 2,
          centerY: y0 + halfH / 2,
          pathD: path,
        });
      }
    }
  } else if (count === 7) {
    const halfH = H / 2;
    const topW = W / 3;
    const btmW = W / 4;

    for (let c = 0; c < 3; c++) {
      const x0 = c * topW;
      const x1 = (c + 1) * topW;
      pieces.push({
        index: c,
        x: x0,
        y: 0,
        w: topW,
        h: halfH,
        centerX: x0 + topW / 2,
        centerY: halfH / 2,
        pathD: `M ${x0} 0 L ${c === 2 ? W : x1} 0 L ${c === 2 ? W : x1} ${halfH} L ${x0} ${halfH} Z`,
      });
    }
    for (let c = 0; c < 4; c++) {
      const x0 = c * btmW;
      const x1 = (c + 1) * btmW;
      pieces.push({
        index: 3 + c,
        x: x0,
        y: halfH,
        w: btmW,
        h: halfH,
        centerX: x0 + btmW / 2,
        centerY: halfH + halfH / 2,
        pathD: `M ${x0} ${halfH} L ${c === 3 ? W : x1} ${halfH} L ${c === 3 ? W : x1} ${H} L ${x0} ${H} Z`,
      });
    }
  } else if (count === 8) {
    const halfH = H / 2;
    const colW = W / 4;
    for (let r = 0; r < 2; r++) {
      const y0 = r * halfH;
      const y1 = (r + 1) * halfH;
      for (let c = 0; c < 4; c++) {
        const x0 = c * colW;
        const x1 = (c + 1) * colW;
        const idx = r * 4 + c;
        pieces.push({
          index: idx,
          x: x0,
          y: y0,
          w: colW,
          h: halfH,
          centerX: x0 + colW / 2,
          centerY: y0 + halfH / 2,
          pathD: `M ${x0} ${y0} L ${c === 3 ? W : x1} ${y0} L ${c === 3 ? W : x1} ${y1} L ${x0} ${y1} Z`,
        });
      }
    }
  } else if (count === 9) {
    const rowH = H / 3;
    const colW = W / 3;
    for (let r = 0; r < 3; r++) {
      const y0 = r * rowH;
      const y1 = (r + 1) * rowH;
      for (let c = 0; c < 3; c++) {
        const x0 = c * colW;
        const x1 = (c + 1) * colW;
        const idx = r * 3 + c;
        pieces.push({
          index: idx,
          x: x0,
          y: y0,
          w: colW,
          h: rowH,
          centerX: x0 + colW / 2,
          centerY: y0 + rowH / 2,
          pathD: `M ${x0} ${y0} L ${c === 2 ? W : x1} ${y0} L ${c === 2 ? W : x1} ${y1} L ${x0} ${y1} Z`,
        });
      }
    }
  } else {
    // 10
    const halfH = H / 2;
    const colW = W / 5;
    for (let r = 0; r < 2; r++) {
      const y0 = r * halfH;
      const y1 = (r + 1) * halfH;
      for (let c = 0; c < 5; c++) {
        const x0 = c * colW;
        const x1 = (c + 1) * colW;
        const idx = r * 5 + c;
        pieces.push({
          index: idx,
          x: x0,
          y: y0,
          w: colW,
          h: halfH,
          centerX: x0 + colW / 2,
          centerY: y0 + halfH / 2,
          pathD: `M ${x0} ${y0} L ${c === 4 ? W : x1} ${y0} L ${c === 4 ? W : x1} ${y1} L ${x0} ${y1} Z`,
        });
      }
    }
  }

  return pieces;
}

export const PuzzleArtwork: React.FC<PuzzleArtworkProps> = ({
  word,
  revealedIndices,
  activeWordUserColors = {},
  onPieceClick,
  interactive = true,
}) => {
  const count = word.english.length;
  const pieces = React.useMemo(() => generatePuzzlePieces(count, 260, 260), [count]);
  const isFullyCompleted = revealedIndices.length >= count;

  // Fully colored artwork
  const fullColoredParts = React.useMemo(() => {
    return { ...word.defaultParts, ...activeWordUserColors };
  }, [word.defaultParts, activeWordUserColors]);

  // Clean uncolored sketch outlines for unrevealed artwork parts
  const sketchParts = React.useMemo(() => {
    const res: Record<string, string> = {};
    Object.keys(word.defaultParts).forEach((k) => {
      res[k] = '#FFFFFF';
    });
    return res;
  }, [word.defaultParts]);

  return (
    <div className="relative w-full h-full flex items-center justify-center select-none">
      <svg
        viewBox="0 0 260 260"
        className="w-full h-full overflow-visible"
        style={{ touchAction: 'manipulation' }}
      >
        <defs>
          {/* Clip path for each puzzle piece */}
          {pieces.map((p) => (
            <clipPath key={p.index} id={`puzzle-clip-${word.id}-${p.index}`}>
              <path d={p.pathD} />
            </clipPath>
          ))}
        </defs>

        {/* 1. Base Layer: Clean Sketch Drawing of the Character ONLY (No background cuts) */}
        <g opacity="0.32">
          <RenderArtwork
            wordId={word.id}
            parts={sketchParts}
            interactive={false}
          />
        </g>

        {/* 2. Revealed Pieces: Render the colored character inside each unlocked puzzle slice */}
        {pieces.map((piece) => {
          const isRevealed = revealedIndices.includes(piece.index);
          const clipId = `puzzle-clip-${word.id}-${piece.index}`;

          return (
            <g
              key={piece.index}
              onClick={() => {
                if (interactive && onPieceClick) {
                  onPieceClick(piece.index);
                }
              }}
              className={`transition-all duration-300 ${
                interactive && !isRevealed ? 'cursor-pointer hover:opacity-90' : ''
              }`}
            >
              {/* Colored artwork clipped to this puzzle piece */}
              {isRevealed && (
                <g clipPath={`url(#${clipId})`} className="animate-fade-in">
                  <RenderArtwork
                    wordId={word.id}
                    parts={fullColoredParts}
                    interactive={false}
                  />
                </g>
              )}

              {/* Subtle Soft Puzzle Division Lines over the Character (No numbers) */}
              {!isFullyCompleted && (
                <path
                  d={piece.pathD}
                  fill="none"
                  stroke={isRevealed ? '#F59E0B' : '#94A3B8'}
                  strokeWidth="1.8"
                  strokeDasharray={!isRevealed ? '5,4' : undefined}
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="pointer-events-none transition-all duration-300"
                  opacity={isRevealed ? 0.5 : 0.6}
                />
              )}
            </g>
          );
        })}
      </svg>
    </div>
  );
};
